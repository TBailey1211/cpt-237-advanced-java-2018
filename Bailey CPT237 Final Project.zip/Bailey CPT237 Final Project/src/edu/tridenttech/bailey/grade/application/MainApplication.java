package edu.tridenttech.bailey.grade.application;

import edu.tridenttech.bailey.grade.model.GradeProgram;
import edu.tridenttech.bailey.grade.model.Student;
import edu.tridenttech.bailey.grade.view.MainWindow;
import javafx.application.Application;
import javafx.stage.Stage;

public class MainApplication extends Application
{

	@Override
	public void start(Stage primaryStage) throws Exception 
	{
		new MainWindow(primaryStage).show();
		//get instance
		GradeProgram gradeProgram = GradeProgram.getInstance();
		//load students
		gradeProgram.loadStudents("C:\\Users\\Taylor\\Desktop\\Students.txt");
	}

	public static void main(String[] args)
	{
		Application.launch(args);
	}

}
