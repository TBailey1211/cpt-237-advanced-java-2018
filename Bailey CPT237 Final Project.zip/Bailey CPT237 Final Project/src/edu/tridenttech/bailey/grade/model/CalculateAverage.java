package edu.tridenttech.bailey.grade.model;

public class CalculateAverage 
{
	int total;
	int average;
	public int calcAverage(int grade1, int grade2, int grade3)
	{
		total = grade1 + grade2 + grade3;
		average = total / 3;
		return average;
	}
}
