package edu.tridenttech.bailey.grade.model;

import java.util.ArrayList;
import java.util.Collections;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;


public class GradeProgram 
{
	private static GradeProgram instance = new GradeProgram();
	ArrayList<Student> students = new ArrayList<Student>();
	
	//(1) Singleton: create a static instance
	static GradeProgram myGradeProgram = new GradeProgram();
	
	//(2) Singleton: create a private constructor
	private GradeProgram()
	{
			
	}
	
	//(3) Singleton: create a static method [getInstance]
	public static GradeProgram getInstance()
	{
		return instance;
	}
	
	//Load students from file into ArrayList
	public void loadStudents(String filename)
	{
		try
		{
			Scanner input = new Scanner(new File(filename));
			String name = "";
			int grade1;
			int grade2;
			int grade3;
			
			while (input.hasNext())
			{
				Student s;
				String line;
				line = input.nextLine();
				String[] fields = line.split(",");
				name = fields[0];
				grade1 = Integer.parseInt(fields[1]);
				grade2 = Integer.parseInt(fields[2]);
				grade3 = Integer.parseInt(fields[3]);
				
				s = new Student(name, grade1, grade2, grade3);
				
				/*for (int i=1; i < fields.length; i++)
				{
					grade = Integer.parseInt(fields[i]);
					s.addGrade(grade);
				}*/
				
				students.add(s);
				
				if (fields.length > 4)
				{
					System.out.println("ERROR: Error with line. Too many parameters at line. Please correct error in file." + "." + "'" + line + "'");
					System.exit(0);
				}				
			}
			input.close();
			
			/*for (Student student : students)
			{
				System.out.println(student.getName() + ": " + student.getGrade1() + " " + student.getGrade2() + " " + student.getGrade3());
			}*/
		}
		
		catch (Exception e)
		{
			System.out.println("File has not been read successfully.");
		}
	}
	
	public List<String> getStudentNames()
	{
		ArrayList<String> names = new ArrayList<>();
		for (Student student : students)
		{
			names.add(student.getName());	
		}
		return names;
	}
	
	public List<Student> getStudentList()
	{
		List<Student> unmodifiableList = Collections.unmodifiableList(students);
		return unmodifiableList;
	}
	
	public Student getStudentByName(String name)
	{
		Student student = null;
		Optional<Student> match = students.stream().filter(e -> e.getName().equals(name)).findFirst();
		if (match.isPresent()) 
		{
			student = match.get();
		}
		return student;
	}
	
	public boolean addNewStudent(String name, int grade1, int grade2, int grade3)
	{
		Student student = new Student(name, grade1, grade2, grade3);
		return students.add(student);
	}

}
