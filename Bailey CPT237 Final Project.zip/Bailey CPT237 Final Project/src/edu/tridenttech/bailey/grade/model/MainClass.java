package edu.tridenttech.bailey.grade.model;

public class MainClass 
{

	public static void main(String[] args) 
	{
		
	}

}
