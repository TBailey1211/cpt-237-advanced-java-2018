package edu.tridenttech.bailey.grade.model;

import java.util.ArrayList;
import java.util.Comparator;

public class Student implements Comparable<Student>
{
	private String name;
	protected int grade1;
	protected int grade2;
	protected int grade3;
	//ArrayList<Integer> grades = new ArrayList<>();
	
	public Student(String name, int grade1, int grade2, int grade3)
	{
		this.name = name;
		this.grade1 = grade1;
		this.grade2 = grade2;
		this.grade3 = grade3;
	}
	
	public String getName()
	{
		return name;
	}
	
	public int getGrade1()
	{
		return grade1;
	}
	
	public int getGrade2()
	{
		return grade2;
	}
	
	public int getGrade3()
	{
		return grade3;
	}

	@Override
	public int compareTo(Student a) 
	{
		return this.name.compareTo(a.getName());
	}
	
}
