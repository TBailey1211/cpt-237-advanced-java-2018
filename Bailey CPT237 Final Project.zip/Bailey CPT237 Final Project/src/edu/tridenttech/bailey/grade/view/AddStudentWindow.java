package edu.tridenttech.bailey.grade.view;

import java.nio.file.Files;
import java.util.List;

import edu.tridenttech.bailey.grade.model.CalculateAverage;
import edu.tridenttech.bailey.grade.model.GradeProgram;
import edu.tridenttech.bailey.grade.model.Student;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class AddStudentWindow 
{
	Label lbl;
	Label lbl2;
	Label lbl3;
	Label lbl4;
	Label lbl5;
	private Stage myStage;
	private TextField studentName = new TextField();
	private TextField grade1 = new TextField();
	private TextField grade2 = new TextField();
	private TextField grade3 = new TextField();
	Button okBtn = new Button("Ok");
	Button clearBtn = new Button("Clear");
	Button closeBtn = new Button("Close");
	
	public AddStudentWindow()
	{
		FlowPane pane = new FlowPane();
		pane.setOrientation(Orientation.HORIZONTAL);
		Scene scene = new Scene(pane);
		
		myStage = new Stage();
		myStage.setScene(scene);
		myStage.setTitle("Grade Calculator Program");
		myStage.setWidth(300);
		myStage.setHeight(400);
		
		lbl = new Label("Input Student's Name:");
		lbl2 = new Label("Input Student's Grades:");
		lbl3 = new Label("<- Grade 1");
		lbl4 = new Label("<- Grade 2");
		lbl5 = new Label("<- Grade 3");
		
		pane.getChildren().add(lbl);
		pane.getChildren().add(studentName);
		pane.getChildren().add(lbl2);
		pane.getChildren().add(grade1);
		pane.getChildren().add(lbl3);
		pane.getChildren().add(grade2);
		pane.getChildren().add(lbl4);
		pane.getChildren().add(grade3);
		pane.getChildren().add(lbl5);
		pane.getChildren().add(okBtn);
		pane.getChildren().add(clearBtn);
		pane.getChildren().add(closeBtn);
		
		okBtn.setOnAction(e -> OkHandle(e));
		clearBtn.setOnAction(e -> ClearHandle(e));
		closeBtn.setOnAction(e -> CloseHandle(e));
		
	}
	
	public void OkHandle(ActionEvent e)
	{
		GradeProgram gradeProgram = GradeProgram.getInstance();
		String name = studentName.getText();
		int gradeOne = Integer.parseInt(grade1.getText());
		int gradeTwo = Integer.parseInt(grade2.getText());
		int gradeThree = Integer.parseInt(grade3.getText());
		gradeProgram.addNewStudent(name, gradeOne, gradeTwo, gradeThree);
		myStage.close();
	}
	
	public void ClearHandle(ActionEvent e)
	{
		studentName.setText("");
		grade1.setText("");
		grade2.setText("");
		grade3.setText("");
	}
	
	public void CloseHandle(ActionEvent e)
	{
		myStage.close();
	}
	
	public void show()
	{
		myStage.show();
	}
	
}
