package edu.tridenttech.bailey.grade.view;

import java.nio.file.Files;
import java.util.List;

import edu.tridenttech.bailey.grade.model.CalculateAverage;
import edu.tridenttech.bailey.grade.model.GradeProgram;
import edu.tridenttech.bailey.grade.model.Student;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;


public class GradeCalculatorWindow
{
	Label lbl;
	Label lbl2;
	private Stage myStage;
	private ComboBox<String> studentList = new ComboBox();
	TextArea studentInfo = new TextArea();
	Button getInfoBtn = new Button("Get Info");
	Button clearBtn = new Button("Clear");
	Button closeBtn = new Button("Close");
	
	public GradeCalculatorWindow()
	{
		FlowPane pane = new FlowPane();
		pane.setOrientation(Orientation.HORIZONTAL);
		Scene scene = new Scene(pane);
		
		myStage = new Stage();
		myStage.setScene(scene);
		myStage.setTitle("Grade Calculator Program");
		myStage.setWidth(300);
		myStage.setHeight(400);
		
		lbl = new Label("Select student:");
		lbl2 = new Label("Student Grades:");
		
		studentList.getSelectionModel().selectedItemProperty().addListener( (v, oldValue, newValue) -> 
			System.out.println("Currently selected student: " + newValue) );
		
		pane.getChildren().add(lbl);
		pane.getChildren().add(studentList);
		pane.getChildren().add(getInfoBtn);
		pane.getChildren().add(lbl2);
		pane.getChildren().add(studentInfo);
		pane.getChildren().add(clearBtn);
		pane.getChildren().add(closeBtn);
		
		getInfoBtn.setOnAction(e -> StudentInfo(e));
		clearBtn.setOnAction(e -> ClearHandle(e));
		closeBtn.setOnAction(e -> CloseHandle(e));
	}
	
	public void StudentInfo(ActionEvent e)
	{
		GradeProgram gradeProgram = GradeProgram.getInstance();
		String selectedStudent = studentList.getValue();
		Student student = gradeProgram.getStudentByName(selectedStudent);
		int grade1 = student.getGrade1();
		int grade2 = student.getGrade2();
		int grade3 = student.getGrade3();
		CalculateAverage calcAverage = new CalculateAverage();
		int average = calcAverage.calcAverage(grade1, grade2, grade3);
		studentInfo.setWrapText(true);
		//Student student = new Student(selectedStudent, grade1, grade2, grade3);
		studentInfo.setText("Student: " + selectedStudent);
		studentInfo.appendText("\nStudent Grades: " + grade1 + " " + grade2 + " " + grade3);
		studentInfo.appendText("\nStudent's Current Average: " + average);
		
		studentInfo.setEditable(false);
	}
	
	public void show(List<String> students)
	{
		studentList.getItems().setAll(students);
		studentList.setValue(students.get(0));
		myStage.show();
	}
	
	public void ClearHandle(ActionEvent e)
	{
		studentInfo.setText("");
	}
	
	public void CloseHandle(ActionEvent e)
	{
		myStage.close();
	}
}
