package edu.tridenttech.bailey.grade.view;

import java.util.List;

import edu.tridenttech.bailey.grade.model.GradeProgram;
import edu.tridenttech.bailey.grade.model.Student;
import edu.tridenttech.bailey.grade.view.GradeCalculatorWindow;
import edu.tridenttech.bailey.grade.view.AddStudentWindow;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class MainWindow implements EventHandler<ActionEvent>
{
	private GradeCalculatorWindow gradeCalculator = new GradeCalculatorWindow();
	private StudentSortWindow studentSort = new StudentSortWindow();
	private AddStudentWindow addStudent = new AddStudentWindow();
	
	private Stage myStage;
	Button closeBtn = new Button("Close");
	Button gradeCalcBtn = new Button("Begin Grade Calculator");
	Button studentSortBtn = new Button("Sort Students");
	Button addStudentBtn = new Button("Add New Student");
	Label lbl;
	
	public MainWindow(Stage primaryStage)
	{
		FlowPane pane = new FlowPane();
		pane.setOrientation(Orientation.HORIZONTAL);
		Scene scene = new Scene(pane);
		
		myStage = new Stage();
		myStage.setScene(scene);
		myStage.setTitle("Grade Calculator Program");
		myStage.setWidth(450);
		myStage.setHeight(200);
		
		lbl = new Label("Welcome to the Grade Calculation Program. \nClick 'Begin Grade Calculator' to begin calculating \naverages with select students."
				+ "\nClick 'Sort Students' to begin sorting your list of students.");
		
		pane.getChildren().add(lbl);
		pane.getChildren().add(gradeCalcBtn);
		pane.getChildren().add(studentSortBtn);
		pane.getChildren().add(addStudentBtn);
		pane.getChildren().add(closeBtn);
		
		closeBtn.setOnAction(e -> CloseHandle(e));
		gradeCalcBtn.setOnAction(new GradeHandle());
		studentSortBtn.setOnAction(e -> SortHandle(e));
		addStudentBtn.setOnAction(e -> AddHandle(e));

	}
	
	public void show()
	{
		myStage.show();
	}
	
	public void CloseHandle (ActionEvent e)
	{
		myStage.close();
	}
	
	public class GradeHandle implements EventHandler<ActionEvent>
	{

		@Override
		public void handle(ActionEvent event) 
		{
			List<String> studentList = GradeProgram.getInstance().getStudentNames();
			gradeCalculator.show(studentList);
		}
	}
	
	public void SortHandle(ActionEvent e)
	{
		studentSort.show();
	}
	
	public void AddHandle(ActionEvent e)
	{
		addStudent.show();
	}
	
	@Override
	public void handle(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
