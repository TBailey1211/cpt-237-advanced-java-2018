package edu.tridenttech.bailey.grade.view;

import edu.tridenttech.bailey.grade.model.CalculateAverage;
import edu.tridenttech.bailey.grade.model.GradeProgram;
import edu.tridenttech.bailey.grade.model.Student;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javafx.scene.control.ListView;
import javafx.scene.control.ListCell;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class StudentSortWindow
{
	Label lbl;
	private Stage myStage;
	Button showStudentsBtn = new Button("Show Student List");
	Button studentSortBtn = new Button("Sort by ABC Order");
	Button reverseSortBtn = new Button("Sort in Reverse Order");
	Button closeBtn = new Button("Close");
	TextArea studentInfo = new TextArea();
	
	public StudentSortWindow()
	{
		FlowPane pane = new FlowPane();
		pane.setOrientation(Orientation.HORIZONTAL);
		Scene scene = new Scene(pane);
		
		myStage = new Stage();
		myStage.setScene(scene);
		myStage.setTitle("Grade Calculator Program");
		myStage.setWidth(300);
		myStage.setHeight(500);
		studentInfo.setPrefColumnCount(10);
		studentInfo.setPrefRowCount(10);
		studentInfo.setPrefSize(300, 300);
		
		lbl = new Label("Choose method of sorting:");
		
		pane.getChildren().add(lbl);
		pane.getChildren().add(showStudentsBtn);
		pane.getChildren().add(studentSortBtn);
		pane.getChildren().add(reverseSortBtn);
		pane.getChildren().add(studentInfo);
		pane.getChildren().add(closeBtn);
		
		showStudentsBtn.setOnAction(e -> ShowStudentsHandle(e));
		studentSortBtn.setOnAction(e -> SortStudentsHandle(e));
		reverseSortBtn.setOnAction(e -> ReverseStudentsHandle(e));
		closeBtn.setOnAction(e -> CloseHandle(e));
	}
	
	public void CloseHandle(ActionEvent e)
	{
		myStage.close();
	}
	
	public void ShowStudentsHandle(ActionEvent e)
	{ 
		studentInfo.setText("");
		GradeProgram gradeProgram = GradeProgram.getInstance();
		List <Student> studentList = gradeProgram.getStudentList();
		for (Student student : studentList)
		{
			String students;
			students = String.format("\n%10s%5d%5d%5d", student.getName(), student.getGrade1(), student.getGrade2(), student.getGrade3());
			studentInfo.appendText(students);
			studentInfo.setFont(Font.font("Consolas"));
		}
	}
	
	public void SortStudentsHandle(ActionEvent e)
	{
		studentInfo.setText("");
		GradeProgram gradeProgram = GradeProgram.getInstance();
		List <Student> studentList = new ArrayList<Student>(gradeProgram.getStudentList());
		
		Collections.sort(studentList);
		
		for (Student student : studentList)
		{
			String students;
			students = String.format("\n%10s%5d%5d%5d", student.getName(), student.getGrade1(), student.getGrade2(), student.getGrade3());
			studentInfo.appendText(students);
			studentInfo.setFont(Font.font("Consolas"));
		}
	}
	
	public void ReverseStudentsHandle(ActionEvent e)
	{
		studentInfo.setText("");
		GradeProgram gradeProgram = GradeProgram.getInstance();
		List <Student> studentList = new ArrayList<Student>(gradeProgram.getStudentList());
		
		Collections.reverse(studentList);
		
		for (Student student : studentList)
		{
			String students;
			students = String.format("\n%10s%5d%5d%5d", student.getName(), student.getGrade1(), student.getGrade2(), student.getGrade3());
			studentInfo.appendText(students);
			studentInfo.setFont(Font.font("Consolas"));
		}
	}

	public void show() 
	{
		myStage.show();
	}
}
