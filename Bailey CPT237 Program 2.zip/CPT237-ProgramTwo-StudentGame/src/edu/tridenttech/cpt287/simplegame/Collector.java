package edu.tridenttech.cpt287.simplegame;

public interface Collector 
{
	int getNumVials(); //returns # of vials entity has
	void addVials(int vialsAdded); //adds vials to # collected; accepts int (# of vials to add) as parameter
	int relinquishVials(); //causes the entity to reduce number of vials to 0
						   //returns the # of vials it had to the player
}
