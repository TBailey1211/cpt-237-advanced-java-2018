package edu.tridenttech.cpt287.simplegame;

public class Enemy extends Obstacle implements Warrior, Collector
{
	private int speed;
	private int numVials;
	protected boolean canEntityAttack = false;
	
	/**
	 * Creates an Enemy with the given parameters.  The points are calculated by adding the strength plus half the speed.
	 * @param name The name of this enemy
	 * @param strength Strength used in determining damage done to opponent
	 * @param speed Speed used to determine whether opponent is caught when pursued
	 * @param numVials The number of vials currently in this Enemy's possession
	 */
	public Enemy(String name, int strength, int speed, int numVials)
	{
		super(name, strength);
		this.numVials = numVials;
		this.speed = speed;
	}

	/**
	 * Creates an Enemy with the given parameters.
	 * @param name The name of this enemy
	 * @param strength Strength used in determining damage done to opponent
	 * @param speed Speed used to determine whether opponent is caught when pursued
	 * @param numVials The number of vials currently in this Enemy's possession
	 * @param points The number points that this Enemy is worth
	 */
	public Enemy(String name, int strength, int speed, int numVials, int points)
	{
		super(name, strength, points);
		this.numVials = numVials;
		this.speed = speed;
	}
	
	// This implements the attack method for the Enemy.  Do not modify.
	public void attack(GameEntity player)
	{
		Game.getInstance().attack(this, player);
	}

	//Implement getNumVials
	@Override
	public int getNumVials() 
	{
		return numVials;
	}

	//Implement addVials
	@Override
	public void addVials(int vialsAdded) 
	{
		numVials = numVials + vialsAdded;
	}

	//Implement relinquishVials [check for accuracy in testing]
	@Override
	public int relinquishVials() 
	{
		int enemyVials;
		enemyVials = numVials;
		enemyVials = 0;
		return numVials;
		/*int vialsAdded = 0;
		addVials(vialsAdded);
		numVials = 0;
		return numVials;*/
	}

	//Implement getSpeed
	@Override
	public int getSpeed() 
	{
		return speed;
	}

	//Implement canAttack [changed health from private to protected]
	@Override
	public boolean canAttack() 
	{
		if (health <= 0)
		{
		return canEntityAttack;
		}
		else
		{
		return true;
		}
	}

}
