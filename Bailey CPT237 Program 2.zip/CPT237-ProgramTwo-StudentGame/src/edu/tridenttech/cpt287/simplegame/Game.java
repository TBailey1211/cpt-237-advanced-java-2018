package edu.tridenttech.cpt287.simplegame;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Game
{
	final public int ATTACK_LOSS_FACTOR = 5;
	final public int DEFEND_LOSS_FACTOR = 6;
	final public int MAX_STRENGTH = 10;
	final public int DEFAULT_STRENGTH = 6;
	final public int MAX_ABILITIES = 15;

	Scanner console = new Scanner(System.in);
	Random rand = new Random();

	ArrayList<Obstacle> opponents = new ArrayList<>();
	
	//(1) Singleton: create a static instance
	static Game myGame = new Game();
	
	//(2) Singleton: create a private constructor
	private Game()
	{
		
	}
	
	//(3) Singleton: create a static method [getInstance]
	public static Game getInstance()
	{
		return myGame;
	}

	// TODO -- add the code needed to make the Game a singleton
	
	// TODO, fix the loadChallenge method such that it reads from
	// the filename.
	public void loadOpponents(String filename)
	{
		// TODO
		// Replace the code below with code that reads values from
		// the given file and creates the appropriate opponent.
		// You will need to check whether the first field is Troll,
		// Jinn, Wall, etc. to determine the type of opponent to create.
		// Once the opponent is created, add it to the opponents array list.
		
		try
		{
			Scanner input = new Scanner(new File(filename));
			
			while (input.hasNext())
			{
				//Read one line
				String line = input.nextLine();
				String[] fields = line.split(",");
				String name = fields[0];
				
				//Create an opponent from the line (depending on opponent type)
				if (name.equals("Jinn"))
				{
					int numVials = Integer.parseInt(fields[1]);
					opponents.add(new Jinn(numVials));
				}
				else if (name.equals("Troll"))
				{
					int numVials = Integer.parseInt(fields[1]);
					opponents.add(new Troll(numVials));
				}
				else if (name.equals("Goblin"))
				{
					int numVials = Integer.parseInt(fields[1]);
					opponents.add(new Goblin(numVials));
				}
				else if (name.equals("Wall"))
				{
					opponents.add(new Wall());
				}
				else if (name.equals("Well"))
				{
					int numVials = Integer.parseInt(fields[1]);
					opponents.add(new Well(numVials));
				}
				else
				{
					try 
					{
					int strength = Integer.parseInt(fields[1]);
					int speed = Integer.parseInt(fields[2]);
					int numVials = Integer.parseInt(fields[3]);
					int points = Integer.parseInt(fields[4]);
					
					opponents.add(new Enemy(name, strength, speed, numVials, points));
					
					if (fields.length > 5)
					{
						System.out.println("Error with line. Too many parameters at line" + "." + "'" + line + "'");
					}
					
					}
					
					catch (Exception e)
					{
						System.out.println("Error with line: " + line + " "+ e);
					}
				}
				
			}
			input.close();
		}
				
		catch (Exception e)
		{
			System.out.println("File not read. Opponents not loaded successfully.");
		}
		
	}
	
	public void play()
	{
		Player player;
		//Added [2nd Player]
		Player player2 = null;
		Player currentPlayer;
		String name;
		int strength;
		Obstacle badGuy = null;
		//Added [2nd Player]
		int numPlayers;
		int loopCount = 0;

		// have we loaded the opponents?
		if (opponents.size() == 0) {
			System.err.println("No opponents have been loaded");
			return;
		}
		
		//Added [2nd Player]
		System.out.println("How many Players? [1 or 2]");
		numPlayers = console.nextInt();
		console.nextLine();
	   
		System.out.print("Please enter a name for your player. ");
		name = console.nextLine();
		System.out.printf("Please enter the strength for %s.[1-10] ", name);
		strength = console.nextInt();
		console.nextLine();

		if (strength > MAX_STRENGTH || strength < 1)
		{
			System.err.printf("invalid strength, setting to default(%d)%n", DEFAULT_STRENGTH);
			strength = DEFAULT_STRENGTH;
		}

		player = new Player(name, strength, MAX_ABILITIES - strength);
		
		//Added [2nd Player]
		if (numPlayers == 2)
		{
			System.out.print("Please enter a name for your player. ");
			name = console.nextLine();
			System.out.printf("Please enter the strength for %s.[1-10] ", name);
			strength = console.nextInt();
			console.nextLine();

			if (strength > MAX_STRENGTH || strength < 1)
			{
				System.err.printf("invalid strength, setting to default(%d)%n", DEFAULT_STRENGTH);
				strength = DEFAULT_STRENGTH;
			}

			player2 = new Player(name, strength, MAX_ABILITIES - strength);
		}
		

		// while loop to play game
		while (opponents.size() > 0)
		{
			currentPlayer = player;
			if (numPlayers == 2)
			{
				if (loopCount % 2 == 0) 
					{
		        currentPlayer = player;
					} 
				else 
					{
		        currentPlayer = player2;
					}
				
				if(!player.isAlive())
				{
					currentPlayer = player2;
				}
				else if (!player2.isAlive())
				{
					currentPlayer = player;
				}
				
			}
			int selection;
			// get the opponent at the top of the list
			if (badGuy == null || !badGuy.isAlive())
			{
				badGuy = opponents.remove(opponents.size()-1);
			}

			// display information to the user
			show(currentPlayer);
			show(badGuy);

			selection = getMenuSelection();
			switch (selection)
			{
				case 'R':
					System.out.println("RETREAT!");
					retreat(currentPlayer, badGuy);
					if (!badGuy.isAlive())
					{
						// announce the defeat and award points
						System.out.printf("Congratulations!  You have defeated %s%n", badGuy.getName());
						currentPlayer.addPoints(badGuy.getPoints());
					} else {
						// return the opponent to the list
						opponents.add(rand.nextInt(opponents.size()-1), badGuy);
						badGuy = null;
					}
				break;
				case 'A':
					System.out.println("ATTACK!");
					currentPlayer.attack(badGuy);
					if (!badGuy.isAlive()) {
						System.out.printf("Congratulations!  You have defeated %s%n", badGuy.getName());
						currentPlayer.addPoints(badGuy.getPoints());
						if (badGuy.getName().equals("Well"))
						{
							int vialsCollected = 0;
							currentPlayer.addVials(vialsCollected);
						}
					}
				break;
				case 'D':
					System.out.println("DRINK!");
					drink(currentPlayer);
				break;
				case 'Q':
					System.out.println("QUIT!");
				return;
			}
			if (!currentPlayer.isAlive())
			{
				System.out.printf("Sorry, %s!  You have been killed %n", currentPlayer.getName());
				
				if (badGuy.getName().equals("Well"))
				{
					int vialsCollected = currentPlayer.getNumVials();
				}
				
				//return;
			}
			
			if (numPlayers == 1 && !currentPlayer.isAlive())
			{
				return;
			}
			
			if (!player.isAlive() && !player2.isAlive())
			{
				System.out.println("Sorry! Both players have been killed. GAME OVER.");
				return;
			}
			loopCount++;
		}
	}
	
	private int getMenuSelection()
	{
		char selection = 'x';

		System.out.println("What would you like to do?");
		System.out.println("(R)etreat");
		System.out.println("(A)ttack");
		System.out.println("(D)rink vial");
		System.out.println("(Q)uit");
		selection = console.next().charAt(0);
		return Character.toUpperCase(selection);
	}

	private void show(GameEntity o)
	{
		System.out.println("-----------------------------");
		System.out.printf("Name:     %10s%n", o.getName());
		System.out.printf("Strength: %10d%n", o.getStrength());
		System.out.printf("Health:   %10d%n", o.getHealth());
		System.out.printf("Points:   %10d%n", o.getPoints());
		if (o instanceof Collector) {
			System.out.printf("Vials:   %10d%n", ((Collector)o).getNumVials());
		}
	}

	// Note:  may be called from player (attack) or enemy (retreat)
	public void attack(Warrior attacker, GameEntity defender)
	{
		GameEntity winner = null; // 
		GameEntity loser = null;

		// determine losses based on random number
		// the plus one assures that some damage is always inflicted
		int defenderLoss = (rand.nextInt(attacker.getStrength()) + 1) * ATTACK_LOSS_FACTOR;

		// defender losses
		System.err.printf("Defender looses %d%n", defenderLoss);
		defender.reduceHealth(defenderLoss);

		// if defender is killed on first strike, attacker has no loss
		// otherwise, defender strikes back and attacker also loses health
		if (defender.isAlive())
		{
			int attackerLoss = rand.nextInt(defender.getStrength()) * DEFEND_LOSS_FACTOR;
			System.err.printf("Attacker looses %d%n", attackerLoss);
			attacker.reduceHealth(attackerLoss);
			// if the attacker was killed, make the defender the winner
			if (!attacker.isAlive()) {
				winner = defender;
				loser = attacker;
			}
		} else {
			winner = attacker;
			loser = defender;
		}

		// If we have a winner (still alive) and they collects vials, move them to the winner
		if (winner != null && winner.isAlive() && winner instanceof Collector && loser instanceof Collector)
				((Collector)winner).addVials(((Collector)loser).relinquishVials());
	}
	
	// called from player class
	public void retreat(Player currentPlayer, GameEntity defender)
	{
		// can defender attack?
		if (defender instanceof Warrior)
		{
			Warrior pursuer = (Warrior)defender;
			// chase attacker
			// the player with the greater speed has an advantage, but doesn't necessarily win
			if (currentPlayer.getSpeed() * rand.nextDouble() < pursuer.getSpeed() * rand.nextDouble())
			{
				pursuer.attack(currentPlayer);
			}
		}
	}
	
	private void drink(Player currentPlayer)
	{
		currentPlayer.drink();
	}
}
