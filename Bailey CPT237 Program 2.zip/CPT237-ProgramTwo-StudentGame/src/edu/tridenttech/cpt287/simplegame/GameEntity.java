package edu.tridenttech.cpt287.simplegame;

//GameEntity Interface
public interface GameEntity 
{
	public String getName(); //returns name of entity
	public int getStrength(); //returns strength of entity
	public int getHealth(); //returns health of entity
	public int getPoints(); //returns points entity is worth/points Player has achieved
	public void reduceHealth(int reducedHealth); //takes int (health to be reduced) as parameter
	public boolean isAlive(); //returns whether entity is still alive
}
