package edu.tridenttech.cpt287.simplegame;

public class Goblin extends Enemy
{
	private final static int GOBLIN_STRENGTH = 8;
	private final static int GOBLIN_SPEED = 6;
	
	public Goblin(int numVials)
	{
		super("Goblin", GOBLIN_STRENGTH, GOBLIN_SPEED, numVials);
	}
}
