package edu.tridenttech.cpt287.simplegame;

public class LoadOpponents extends Obstacle
{
	public LoadOpponents(String fileName)
	{	
		super(null, 0); 
		
		String[] fields = fileName.split(",");
		
		String tempName = fields[0];
		int tempNumVials = Integer.parseInt(fields[1]);	
		
	}

	
}
