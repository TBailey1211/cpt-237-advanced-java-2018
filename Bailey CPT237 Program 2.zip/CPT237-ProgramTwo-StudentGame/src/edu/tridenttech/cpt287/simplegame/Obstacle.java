package edu.tridenttech.cpt287.simplegame;

public class Obstacle implements GameEntity
{
	protected final String name;
	final private int strength;
	protected int points;
	protected int health = 50;
	private int reducedHealth = 0;
	
	protected Obstacle(String name, int strength)
	{
		this(name, strength, 2*strength);
	}

	protected Obstacle(String name, int strength, int points)
	{
		this.name = name;
		this.strength = strength;
		this.points = points;
	}
	

	//Implement getName
	@Override
	public String getName() 
	{
		return name;
	}

	//Implement getStrength
	@Override
	public int getStrength() 
	{
		return strength;
	}

	//Implement getHealth
	@Override
	public int getHealth() 
	{
		return health;
	}

	//Implement getPoints
	@Override
	public int getPoints() 
	{
		return points;
	}

	//implement reduceHealth
	@Override
	public void reduceHealth(int reducedHealth) 
	{
		health = health - reducedHealth;
	}

	//implement isAlive
	@Override
	public boolean isAlive() 
	{
		if (health <= 0)
		{
		return false;
		}
		else
		{
		return true;
		}
	}
	
}