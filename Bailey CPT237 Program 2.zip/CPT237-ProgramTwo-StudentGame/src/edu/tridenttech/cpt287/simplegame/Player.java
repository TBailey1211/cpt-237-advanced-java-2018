package edu.tridenttech.cpt287.simplegame;

public class Player implements Warrior, Collector
{
	//final modifiers removed
	private int speed = 0;
	private int numVials = 0;
	private String name = "";
	private int strength = 0;
	protected int points = 0;
	protected int health = 50;
	private int reducedHealth = 0;
	protected boolean canEntityAttack = false;
	
	public Player(String name, int strength, int speed)
	{
		this.name = name;
		this.strength = strength;
		this.speed = speed;
	}

	// DO NOT MODIFY
	public void run(GameEntity opponent)
	{
		// calls the retreat method in Game
		Game.getInstance().retreat(this, opponent);
	}

	// DO NOT MODIFY
	public void attack(GameEntity opponent)
	{
		// The player calls the 'attack' method in Game.
		Game.getInstance().attack(this, opponent);
	}

	//Implements getName
	@Override
	public String getName() 
	{
		return name;
	}

	//Implements getStrength
	@Override
	public int getStrength() 
	{
		return strength;
	}

	//Implements getHealth
	@Override
	public int getHealth() 
	{
		return health;
	}

	//Implements getPoints
	@Override
	public int getPoints() 
	{
		return points;
	}
	
	//Adds points
	public void addPoints(int pointsAdded)
	{
		points = points + pointsAdded;
		/*int currentPoints = getPoints();
		currentPoints = currentPoints + pointsAdded;
		currentPoints = points;
		System.out.println(currentPoints);*/
	}
	
	//Drink vial
	public void drink()
	{
		numVials = getNumVials();
		if (numVials == 0)
		{
			System.out.println("You have no vials left!");
		}
		else
		{
			numVials = numVials - 1;
			health = getHealth();
			health = health + 100;
			if (health > 150)
			{
				health = 150;
			}
		}
	}

	//Implements reduceHealth
	@Override
	public void reduceHealth(int reducedHealth) 
	{
		health = health - reducedHealth;
	}

	//Implements isAlive
	@Override
	public boolean isAlive() 
	{
		if (health <= 0)
		{
		return false;
		}
		else
		{
		return true;
		}
	}

	//Implements getNumVials
	@Override
	public int getNumVials() 
	{
		return numVials;
	}

	//Implements addVials
	@Override
	public void addVials(int vialsAdded) 
	{
		numVials = numVials + vialsAdded;
	}

	//Implements relinquishVials
	@Override
	public int relinquishVials() 
	{
		int vialsAdded = 0;
		addVials(vialsAdded);
		numVials = 0;
		return numVials;
	}
	
	//Implements getSpeed
	@Override
	public int getSpeed() 
	{
		return speed;
	}

	//Implements canAttack
	@Override
	public boolean canAttack() {
		if (health <= 0)
		{
		return canEntityAttack;
		}
		else
		{
		return true;
		}
	}

}