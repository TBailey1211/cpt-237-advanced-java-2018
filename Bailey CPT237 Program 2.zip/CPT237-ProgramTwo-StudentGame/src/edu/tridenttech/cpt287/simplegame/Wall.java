package edu.tridenttech.cpt287.simplegame;

public class Wall extends Obstacle
{

	public Wall() 
	{
		super("Wall", 10);
	}
}
