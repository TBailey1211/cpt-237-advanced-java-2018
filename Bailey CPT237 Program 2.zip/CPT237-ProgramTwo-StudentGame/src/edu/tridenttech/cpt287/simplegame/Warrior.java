package edu.tridenttech.cpt287.simplegame;

//Warrior Interface
public interface Warrior extends GameEntity 
{
	public int getSpeed(); //returns speed of entity
	public boolean canAttack(); //returns whether entity can attack. Always TRUE
	public void attack(GameEntity GameEntity); //takes a GameEntity as a parameter, attacks that entity
}
