package edu.tridenttech.cpt287.simplegame;

public class Well extends Obstacle implements Collector
{

	public Well(int numVials) 
	{
		super("Well", 8);
	}

	int numVials;
	int addVials;
	
	@Override
	public int getNumVials() 
	{
		return numVials;
	}

	@Override
	public void addVials(int vialsAdded) 
	{
		numVials = numVials + vialsAdded;
	}

	@Override
	public int relinquishVials() 
	{
		int enemyVials;
		enemyVials = numVials;
		enemyVials = 0;
		return numVials;
	}

}
