package edu.tridenttech.bailey.bank.application;

import edu.tridenttech.bailey.bank.model.Bank;
import edu.tridenttech.bailey.bank.view.MainWindow;
import javafx.application.Application;
import javafx.stage.Stage;

public class MainApplication extends Application
{

     @Override
     public void start(Stage primaryStage) throws Exception
     {
    	 new MainWindow(primaryStage).show();
    	 Bank b = Bank.getInstance();
 		 b.loadTransactions("Transactions.csv");
     }

 public static void main(String[] args)
    {
        Application.launch(args);
    }

}