package edu.tridenttech.bailey.bank.view;

import edu.tridenttech.bailey.bank.model.Account;
import edu.tridenttech.bailey.bank.model.Bank;
import edu.tridenttech.bailey.bank.model.Account.AccountType;
import edu.tridenttech.bailey.bank.view.TransactionWindow;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class CreateAccount 
{
	private Stage myStage;
	Label lbl;
	Label lbl2;
	Label lbl3;
	ToggleGroup group = new ToggleGroup();
	RadioButton savingsBtn = new RadioButton("Savings");
	RadioButton checkingBtn = new RadioButton("Checking");
	Button okBtn = new Button("Ok");
	Button closeBtn = new Button("Close");
	TextField accountNumber = new TextField();
	TextField startingAmount = new TextField();
	
	
	public CreateAccount()
	{
		FlowPane pane = new FlowPane();
		pane.setOrientation(Orientation.HORIZONTAL);
		Scene scene = new Scene(pane);
		
		myStage = new Stage();
		myStage.setScene(scene);
		myStage.setTitle("Create Account");
		myStage.setWidth(300);
		myStage.setHeight(500);
		
		lbl = new Label("Select type of account to create:");
		lbl2 = new Label("Account Number:");
		lbl3 = new Label("Opening Balance:");
		
		savingsBtn.setToggleGroup(group);
		savingsBtn.setSelected(true);
		checkingBtn.setToggleGroup(group);
		
		pane.getChildren().add(lbl);
		pane.getChildren().add(savingsBtn);
		pane.getChildren().add(checkingBtn);
		pane.getChildren().add(lbl2);
		pane.getChildren().add(accountNumber);
		pane.getChildren().add(lbl3);
		pane.getChildren().add(startingAmount);
		pane.getChildren().add(okBtn);
		pane.getChildren().add(closeBtn);
		
		okBtn.setOnAction(e -> OkHandle(e));
		closeBtn.setOnAction(e -> CloseHandle(e));
	}
	
	public void show()
	{
		myStage.show();
	}
	
	public void OkHandle(ActionEvent e)
	{
		Bank bank = Bank.getInstance();
		AccountType type = null;
		if (group.getSelectedToggle() != null)
		{
			RadioButton button = (RadioButton) group.getSelectedToggle();
			if (button.getText().equals("Savings"))
			{
				type = (AccountType.SAVINGS);
			}
			else if (button.getText().equals("Checking"))
			{
				type = (AccountType.CHECKING);
			}
		}
		
		if (type == (AccountType.SAVINGS))
		{
			double balance = Double.parseDouble(startingAmount.getText());
			String accountNum = accountNumber.getText();
			bank.openSavingsAccount(accountNum, balance);
			myStage.close();
		}
		else if (type == (AccountType.CHECKING))
		{
			double balance = Double.parseDouble(startingAmount.getText());
			String accountNum = accountNumber.getText();
			double minBalance = 0;
			bank.openCheckingAccount(accountNum, balance, minBalance);
			myStage.close();
		}
		
		if (accountNumber.getText() == null)
		{
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Warning");
			alert.setHeaderText("Account not created.");
			Button closeButton = new Button("OK");
			alert.showAndWait();
		}
	}
	
	public void CloseHandle(ActionEvent e)
	{
		myStage.close();
	}

}
