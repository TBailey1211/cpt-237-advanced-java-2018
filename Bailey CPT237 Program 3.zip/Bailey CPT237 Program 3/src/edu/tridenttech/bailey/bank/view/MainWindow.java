package edu.tridenttech.bailey.bank.view;

import edu.tridenttech.bailey.bank.model.Account;
import edu.tridenttech.bailey.bank.model.Bank;
import edu.tridenttech.bailey.bank.model.Account.AccountType;
import edu.tridenttech.bailey.bank.view.TransactionWindow;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class MainWindow implements EventHandler<ActionEvent> 
{
	private TransactionWindow transactionWindow = new TransactionWindow();
	private CreateAccount createWindow = new CreateAccount();

	private Stage myStage;
	Button doneBtn = new Button("Done");
	Button transBtn = new Button("Transaction");
	Button createBtn = new Button("Open Account");
	Label lbl;
	
	
	public MainWindow(Stage primaryStage)
	{
		FlowPane pane = new FlowPane();
		pane.setOrientation(Orientation.HORIZONTAL);
		Scene scene = new Scene(pane);
		
		myStage = new Stage();
		myStage.setScene(scene);
		myStage.setTitle("Bank Account Program");
		myStage.setWidth(350);
		myStage.setHeight(200);
		
		lbl = new Label("Welcome to the Bank Account Program. \nClick Transaction to begin performing \ntransactions with a desired account."
				+ "\nClick Open Account to create a new account.");
		
		pane.getChildren().add(lbl);
		pane.getChildren().add(transBtn);
		pane.getChildren().add(createBtn);
		pane.getChildren().add(doneBtn);
		
		doneBtn.setOnAction(e -> DoneHandle(e));
		transBtn.setOnAction(e -> TransHandle(e));
		createBtn.setOnAction(e -> CreateHandle(e));
	}
    
	public void show()
	{
		myStage.show();
	}
	
	
	public void DoneHandle(ActionEvent e)
	{
		myStage.close();
	}
	
	public void TransHandle(ActionEvent e)
	{
		transactionWindow.show();
	}
	
	public void CreateHandle(ActionEvent e)
	{
		createWindow.show();
	}

	@Override
	public void handle(ActionEvent event) 
	{
	
	}
	
	
}