package edu.tridenttech.bailey.bank.view;

import edu.tridenttech.bailey.bank.model.Account;
import edu.tridenttech.bailey.bank.model.Bank;
import edu.tridenttech.bailey.bank.model.Account.AccountType;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class TransactionWindow 
{
	String accountNumber;
	double balance;
	AccountType type;
	private Stage myStage;
	Button loadAccountBtn = new Button("Load Account");
	Button depositBtn = new Button("Deposit");
	Button withdrawBtn = new Button("Withdraw");
	Button doneBtn = new Button("Done");
	Button closeBtn = new Button("Close");
	TextField accountNum = new TextField();
	TextField accountAmount = new TextField();
	TextArea accountInfo = new TextArea();
	Label lbl;
	Label lbl2;

	public TransactionWindow()
	{
		FlowPane pane = new FlowPane();
		pane.setOrientation(Orientation.HORIZONTAL);
		Scene scene = new Scene(pane);
		
		myStage = new Stage();
		myStage.setScene(scene);
		myStage.setTitle("Bank Account Program");
		myStage.setWidth(300);
		myStage.setHeight(500);
		
		lbl = new Label("Please enter your account number:");
		lbl2 = new Label("Amount: ");
		
		pane.getChildren().add(lbl);
		pane.getChildren().add(accountNum);
		pane.getChildren().add(loadAccountBtn);
		pane.getChildren().add(accountInfo);
		pane.getChildren().add(lbl2);
		pane.getChildren().add(accountAmount);
		pane.getChildren().add(depositBtn);
		pane.getChildren().add(withdrawBtn);
		pane.getChildren().add(doneBtn);
		pane.getChildren().add(closeBtn);
		
		loadAccountBtn.setOnAction(e -> LoadAccountHandle(e));
		depositBtn.setOnAction(e -> DepositHandle(e));
		withdrawBtn.setOnAction(e -> WithdrawHandle(e));
		doneBtn.setOnAction(e -> DoneHandle(e));
		closeBtn.setOnAction(e -> CloseHandle(e));
	}
	
	public void show()
	{
		myStage.show();
	}
	
	public void LoadAccountHandle(ActionEvent e) 
	{
		Bank bank = Bank.getInstance();
		String inputNum = accountNum.getText();
		accountInfo.setWrapText(true);
		accountInfo.setText("Account Number: " + inputNum);
		
		Account account = bank.findAccountByNum(inputNum);
		
		if (account == null)
		{
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Warning");
			alert.setHeaderText("Account number not found.");
			alert.setContentText("Please enter a valid account number.");
			Button closeButton = new Button("OK");
			alert.showAndWait();
		}
		
		accountInfo.appendText("\nAccount Type: " + account.getAccountType());
		accountInfo.appendText("\nCurrent Balance: " + String.format("$%.2f", account.getBalance()));


		accountInfo.setEditable(false);
	}
	
	public void DepositHandle(ActionEvent e)
	{
		Bank bank = Bank.getInstance();
		String inputNum = accountNum.getText();
		Account account = bank.findAccountByNum(inputNum);
		double inputAmount = Double.parseDouble(accountAmount.getText());
		account.deposit(inputAmount);
		accountInfo.setText("Account Number: " + inputNum);
		accountInfo.appendText("\nAccount Type: " + account.getAccountType());
		accountInfo.appendText("\nCurrent Balance: " + String.format("$%.2f", account.getBalance()));
	}
	
	public void WithdrawHandle(ActionEvent e)
	{
		Bank bank = Bank.getInstance();
		String inputNum = accountNum.getText();
		Account account = bank.findAccountByNum(inputNum);
		double inputAmount = Double.parseDouble(accountAmount.getText());
		account.withdraw(inputAmount);
		accountInfo.setText("Account Number: " + inputNum);
		accountInfo.appendText("\nAccount Type: " + account.getAccountType());
		accountInfo.appendText("\nCurrent Balance: " + String.format("$%.2f", account.getBalance()));
	}
	
	public void DoneHandle(ActionEvent e)
	{
		accountNum.setText("");
		accountAmount.setText("");
		accountInfo.setText("");
	}
	
	public void CloseHandle(ActionEvent e)
	{
		myStage.close();
	}
}
