package edu.tridenttech.bailey.cards.view;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import edu.tridenttech.bailey.cards.model.Card;
import edu.tridenttech.bailey.cards.model.Deck;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ToggleGroup;

public class HandDisplayWindow
{
	private final int SUIT_SIZE = 13;
	private Image[] cardImages = new Image[4*SUIT_SIZE];
	private Stage myStage;
	ListView<Card> listView = new ListView<>();
	
	Deck deck;
	int handSize;
	ToggleGroup group = new ToggleGroup();
	Button dealBtn = new Button("Deal");
	Button fishBtn = new Button("Go Fish");
	Button spadesBtn = new Button("Spades");
	CheckBox reverse = new CheckBox("Reverse Order (Spades)");

	public HandDisplayWindow(Stage stage, int size)
	{
		handSize = size;
		myStage = stage;
		myStage.setTitle("Card Hand");
		BorderPane pane = new BorderPane();
		Scene scene = new Scene(pane);
		myStage.setScene(scene);
		listView.setCellFactory(param -> new ListCell<Card>() {
			private ImageView imageView = new ImageView();

			@Override
			public void updateItem(Card card, boolean empty)
			{
				super.updateItem(card, empty);
				if (empty) {
					setGraphic(null);
				} else {
					// determine the index of the card
					int index = card.getSuit() * SUIT_SIZE + card.getRank();
					imageView.setImage(cardImages[index]);
					imageView.setPreserveRatio(true);
					imageView.setFitWidth(50);
					setGraphic(imageView);
				}
			}
		});
		
		listView.setOrientation(Orientation.HORIZONTAL);
		pane.setCenter(listView);
		pane.setBottom(dealBtn);
		BorderPane.setAlignment(dealBtn, Pos.CENTER);
		pane.setTop(reverse);
		BorderPane.setAlignment(reverse, Pos.CENTER);
		pane.setRight(fishBtn);;
		pane.setLeft(spadesBtn);
		//Deal Button: Inner Class
		dealBtn.setOnAction(new DealHandler());
		//Fish Button: Lambda
		fishBtn.setOnAction(e -> FishHandle(e, null));
		//Spades Button: Anonymous
		spadesBtn.setOnAction(new EventHandler<ActionEvent>()
				{
					@Override
					public void handle(ActionEvent e)
					{
						ObservableList<Card> hand = null;
						deck.deal(handSize);
						if (deck != null)
						hand = listView.getItems();
						Collections.sort(hand, new Card.CompareByRank());
						myStage.show();
						
						//Handler for if the checkbox is selected
						if (reverse.isSelected())
						{
						deck.deal(handSize);
						if (deck != null)
						hand = listView.getItems();
						Collections.sort(hand, new Card.CompareReverse());
						myStage.show();
						}
						
					}
				});
		

		myStage.setHeight(200);
		myStage.setWidth(82 * handSize);

		loadImages();
		
	} //END DisplayWindow
	
	
	//Inner class for deal button
	class DealHandler
		implements EventHandler<ActionEvent>
	{

		@Override
		public void handle(ActionEvent e)
		{
			deck.deal(handSize);
			if (deck != null)
				listView.getItems().setAll(deck.deal(handSize));
			myStage.show();
		}
	}
	
	//Handler for Fish Button
	public void FishHandle(ActionEvent e, ObservableList<Card> hand)
	{
		deck.deal(handSize);
		if (deck != null)
		hand = listView.getItems();
		Collections.sort(hand);
		myStage.show();
	}

	private void loadImages()
	{
		String resourceDir = "file:resources/cardspng/";
		char[] suits = { 'c', 'd', 'h', 's' };
		char[] rank = { '2', '3', '4', '5', '6', '7', '8', '9', '0', 'j', 'q', 'k', 'a' };
		int slot = 0;
		// load images
		for (int s = 0; s < 4; s++) {
			for (int r = 0; r < SUIT_SIZE; r++) {
				String path = resourceDir + suits[s] + rank[r] + ".png";
				cardImages[slot] = new Image(path);
				slot++;
			}
		}
	}

	public void show(Deck deck)
	{
		this.deck = deck;
		if (deck != null)
			listView.getItems().setAll(deck.deal(handSize));
		myStage.show();
	}
}
