package edu.tridenttech.cpt237.rentals.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LoadRecord extends Rental 
{
	
	
	public LoadRecord(String fileName) throws Exception 
	{
		super(null, null, 0);
		
		String[] fields = fileName.split(",");
		
		//Date? I'm having trouble finding any examples in the reading 
		//for how to handle this data type 
		Date tempDate = new SimpleDateFormat("dd/MM/yyy").parse(fields[0]);
		String tempId = fields[1];
		String tempItemName = fields[2];
		int tempNumPeriods = Integer.parseInt(fields[3]);
		
		setDate(tempDate);
		setRentalId(tempId);
		setItem(tempItemName);
		setNumPeriods(tempNumPeriods);
	}

}
