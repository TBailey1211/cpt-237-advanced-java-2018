package edu.tridenttech.cpt237.rentals.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Rental
{
	protected String itemName;
	private Date date; // 
	protected String rentalPeriod;
	private int numPeriods;
	protected String rentalId;
	protected double discount;
	protected double grossCost;
	protected double finalCost;
	//NEW
	private Date newDate;
	private int newDuration;

	/**
	 * Create a new rental 
	 * @param  Type of item 
	 * @param item Item rented
	 * @param date  Date rented
	 * @param numPeriods Number of 'periods' rented; * definition of period depends on type of rental
	 * @param grossCost Cost without any discounts
	 */
	public Rental(String item, Date date, int numPeriods)
	{
		this.itemName = item;
		this.date = date;
		this.numPeriods = numPeriods;
	}

	public String getItemType()
	{
		return itemName;
	}

	public String getRentalPeriod()
	{
		return rentalPeriod;
	}

	public Date getDate()
	{
		return date;
	}

	public int getNumPeriods()
	{
		return numPeriods;
	}

	public double getGrossCost()
	{
		return grossCost;
	}

	public double getDiscount()
	{
		return discount;
	}
	
	public String getRentalId()
	{
		return rentalId;
	}

	public void setRentalId(String id)
	{
		rentalId = id;
	}

	public void setDate(Date date)
	{
		this.date = date;
	}
	
	public void setItem(String item)
	{
		this.itemName = item;
	}
	
	public void setNumPeriods(int numPeriods)
	{
		this.numPeriods = numPeriods;
	}
	
	//New method for updating duration
	public void setNewDuration(int newDuration)
	{
		this.numPeriods = newDuration;
	}
	

	@Override
	public String toString()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return String.format(
				"%-12s%-15s%-10s%5d  %-8s%12.2f%10.2f%10.2f",
				sdf.format(date), rentalId, itemName, numPeriods, rentalPeriod, getGrossCost(), getDiscount(), getGrossCost() - getDiscount());
	}


}
