package edu.tridenttech.cpt237.rentals.model;

import java.util.Date;

//Subclass for Rental: Weekly
public class Weekly extends Rental 
{
	double discountCabinCost;
	double initialCost;
	int newNumPeriods;
	double cabinCost = 800;

	public Weekly(String item, Date date, int numPeriods) 
	{
		super(item, date, numPeriods);
		
		if (item.equals("Cabin"))
		{
			rentalPeriod = "Weekly";
			if (numPeriods == 1)
			{
				grossCost = cabinCost;
			}
			else if (numPeriods >= 2)
			{
				grossCost = cabinCost * numPeriods;
				newNumPeriods = numPeriods - 1;
				discount = 200 * newNumPeriods;
				/*discount = cabinCost * .25;
				discountCabinCost = cabinCost - discount;
				newNumPeriods = numPeriods - 1;
				grossCost = discountCabinCost * newNumPeriods + cabinCost;*/
			}
		}
		
	}
	
	//Overloaded constructor
	public Weekly(Date date, String rentalId, String item, int numPeriods) 
	{
		super(item, date, numPeriods);
		
		setRentalId(rentalId);
		
		if (item.equals("Cabin"))
		{
			rentalPeriod = "Weekly";
			if (numPeriods == 1)
			{
				grossCost = cabinCost;
			}
			else if (numPeriods >= 2)
			{
				grossCost = cabinCost * numPeriods;
				newNumPeriods = numPeriods - 1;
				discount = 200 * newNumPeriods;
				/*discount = cabinCost * .25;
				discountCabinCost = cabinCost - discount;
				newNumPeriods = numPeriods - 1;
				grossCost = discountCabinCost * newNumPeriods + cabinCost;*/
			}
		}
		
	}
	
}//END
