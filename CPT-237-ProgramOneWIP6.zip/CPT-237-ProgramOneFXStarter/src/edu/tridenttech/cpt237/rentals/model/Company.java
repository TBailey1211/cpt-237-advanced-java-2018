package edu.tridenttech.cpt237.rentals.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Company
{
	//(1) Turning Company to Singleton: create a static instance
	static Company myCompany = new Company();
	
	//(2) Turning Company to Singleton: create a private constructor
	private Company()
	{
		
	}
	
	private String name = "Bert's Beach Rentals";
	// TODO -- you may need more than one list here
	private ArrayList<Rental> rentalList = new ArrayList<>();
	private String[] supportedRentals = {"Bike", "Umbrella", "Getaway", "SeaDoo", "Cabin"};
	private int nextId = 1001;
	
	//Hourly Rentals
	private ArrayList<Hourly> hourlyList = new ArrayList<>();
	private String[] hourlyRentals = {"SeaDoo","Getaway"};
	
	//Daily Rentals
	private ArrayList<Daily> dailyList = new ArrayList<>();
	private String[] dailyRentals = {"Bike", "Umbrella"};
	
	//Weekly Rentals
	private ArrayList<Weekly> weeklyList = new ArrayList<>();
	private String[] weeklyRentals = {"Cabin"};
	
	
	//(3) Turning Company to Singleton: create a static method [getInstance]
	public static Company getInstance()
	{
		return myCompany;
	}
	
	public String getName()
	{
		return name;
	}

	public List<String> getSupportedRentals()
	{
		return Collections.unmodifiableList(Arrays.asList(supportedRentals));
	}

	private String getNextId(Rental r)
	{
		String id = String.format("%s-%d", r.getItemType().toUpperCase(), nextId);
		nextId++;
		return id;
	}

	public void addRental(Rental r)
	{
		// TODO -- this adds all rentals to a single list;
		// you will probably want separate lists for each type (hourly, daily, weekly)
		
		if (r.getRentalPeriod().equals("Hourly"))
		{
			r.setRentalId(getNextId(r));
			hourlyList.add((Hourly)r);
		}
		else if (r.getRentalPeriod().equals("Daily"))
		{
			r.setRentalId(getNextId(r));
			dailyList.add((Daily)r);
		}
		else if (r.getRentalPeriod().equals("Weekly"))
		{
			r.setRentalId(getNextId(r));
			weeklyList.add((Weekly)r);
		}
		else
		{
			System.out.println("Unexpected Rental Period");
		}
		
		//r.setRentalId(getNextId(r));
		//rentalList.add(r);
	}
	
	
	public void updateRental(Rental r, Date newDate, int newDuration)
	{
		r.getDate();
		r.getNumPeriods();
		r.setDate(newDate);
		r.setNewDuration(newDuration);
	}
	
	public void removeRental(Rental r) {
		// TODO remove the rental from the right list based on its type.
		
		if (r.getRentalPeriod().equals("Hourly"))
		{
			hourlyList.remove((Hourly)r);
		}
		else if (r.getRentalPeriod().equals("Daily"))
		{
			dailyList.remove((Daily)r);
		}
		else if (r.getRentalPeriod().equals("Weekly"))
		{
			weeklyList.remove((Weekly)r);
		}
		else
		{
			System.out.println("Removal unsuccessful.");
		}
		
		
	}

	public Rental createRental(String type, Date date, int rentalPeriod)
	{
		// TODO -- create correct rental based on type
		// Getaways and SeaDoos are hourly
		// Bikes and Umbrellas are daily
		// Cabins are Weekly
		// do not add it to the list; the customer must first agree, the addRental will be called.
		//Rental r = new Rental(type, date, rentalPeriod);
		//return r;
		if (type.equals("SeaDoo"))
		{
		Hourly s = new Hourly("SeaDoo", date, rentalPeriod);
		return s;
		}
		else if(type.equals("Getaway"))
		{
		Hourly g = new Hourly("Getaway", date, rentalPeriod);
		return g;
		}
		else if(type.equals("Bike"))
		{
			Daily b = new Daily("Bike", date, rentalPeriod);
			return b;
		}
		else if(type.equals("Umbrella"))
		{
			Daily u = new Daily("Umbrella", date, rentalPeriod);
			return u;
		}
		else
		{
			Weekly c = new Weekly("Cabin", date, rentalPeriod);
			return c;
		}
	}
	
	public Rental findRentalById(String idStr)
	{
		// DONE -- don't require the user to care about case for rental id
		// TODO -- look up rental based on rental id
		
		if (idStr.startsWith("SeaDoo") || idStr.startsWith("Getaway"))
		{
			return hourlyList.get(hourlyList.size()-1);
		}
		else if (idStr.startsWith("Bike") || idStr.startsWith("Umbrella"))
		{
			return dailyList.get(dailyList.size()-1);
		}
		else 
		{
			return weeklyList.get(weeklyList.size()-1);
		}
		
		//return hourlyList.get(hourlyList.size()-1);
		//return dailyList.get(dailyList.size()-1);
		//return dailyList.get(weeklyList.size()-1);
		
		//return rentalList.get(rentalList.size()-1);
		
	}
	
	//type >> typeName
	public List<Rental> getRentalsByType(String type)
	{
		// TODO -- return the correct list based on the typeName
		// Beware of using == with strings; it doesn't work
		if (type.equals("SeaDoo") || type.equals("Getaway"))
		{
			return Collections.unmodifiableList(hourlyList);
		}
		else if (type.equals("Bike") || type.equals("Umbrella"))
		{
			return Collections.unmodifiableList(dailyList);
		}
		else
		{
			return Collections.unmodifiableList(weeklyList);
		//return Collections.unmodifiableList(rentalList);
		}
	}

	private Scanner infile;
	
	public void loadRentals(String filename)
	{
		// TODO -- read rentals from file
		// See the instructions for the format of the file.
		
		ArrayList<LoadRecord> records = new ArrayList<LoadRecord>(); 
		try 
		{
			Scanner input = new Scanner(new File(filename));
			
			while (input.hasNext()) 
			{
				String line = input.nextLine();
				
				LoadRecord r = new LoadRecord(line, null, nextId, line);
				records.add(r);
			}
			input.close();
			
			for (LoadRecord r : records)
			{
				System.out.println(r.getItemType());
			}
		} 
		
		catch (FileNotFoundException e) 
		{
			System.out.println("File not read.");
		}
		
	}

	// This is just a method for showing all of the rentals.  Just printing the rental should be sufficient.
	// the Rental class has a toString method that will work properly.
	public void showAllRentals()
	{
		System.out.printf("%-12s%-15s%-10s%5s  %-8s%12s%10s%10s\n",
				"Date", "RID", "Item Name", "NUM", "PRD", "Orig. Price", "Discount", "Actual");

		// TODO remember to print all of the rentals, not just one type.
		/*for (Rental r : rentalList) {
			System.out.println(r);
		}*/
		
		int hourCount = 0;
		int dayCount = 0;
		int weekCount = 0;
		//hourly
		double hourlyCost = 0;
		double totalHourlyCost = 0;
		double hourlyDiscount = 0;
		double totalHourlyDiscount = 0;
		double finalHourlyTotal = 0;
		//daily
		double dailyCost = 0;
		double totalDailyCost = 0;
		double dailyDiscount = 0;
		double totalDailyDiscount = 0;
		double finalDailyTotal = 0;
		//weekly
		double weeklyCost = 0;
		double totalWeeklyCost = 0;
		double weeklyDiscount = 0;
		double totalWeeklyDiscount = 0;
		double finalWeeklyTotal = 0;
		for (Rental rentalPeriod : hourlyList)
		{
			System.out.println(rentalPeriod);
			hourCount++;
			hourlyCost = rentalPeriod.getGrossCost();
			totalHourlyCost = totalHourlyCost + hourlyCost;
			hourlyDiscount = rentalPeriod.getDiscount();
			totalHourlyDiscount = totalHourlyDiscount + hourlyDiscount;
			finalHourlyTotal = totalHourlyCost - totalHourlyDiscount;
		}
		
		System.out.println("Total Hourly Rentals: " + hourCount);
		System.out.println("Total Hourly Gross Cost: " + totalHourlyCost);
		System.out.println("Final Total: " + finalHourlyTotal);
		
		for (Rental rentalPeriod : dailyList)
		{
			System.out.println(rentalPeriod);
			dayCount++;
			dailyCost = rentalPeriod.getGrossCost();
			totalDailyCost = totalDailyCost + dailyCost;
			dailyDiscount = rentalPeriod.getDiscount();
			totalDailyDiscount = totalDailyDiscount + dailyDiscount;
			finalDailyTotal = totalDailyCost - totalDailyDiscount;
		}
		
		System.out.println("Total Daily Rentals: " + dayCount);
		System.out.println("Total Daily Gross Cost: " + totalDailyCost);
		System.out.println("Final Total: " + finalDailyTotal);
		
		for (Rental rentalPeriod : weeklyList)
		{
			System.out.println(rentalPeriod);
			weekCount++;
			weeklyCost = rentalPeriod.getGrossCost();
			totalWeeklyCost = totalWeeklyCost + weeklyCost;
			weeklyDiscount = rentalPeriod.getDiscount();
			totalWeeklyDiscount = totalWeeklyDiscount + weeklyDiscount;
			finalWeeklyTotal = totalWeeklyCost - totalWeeklyDiscount;
		}
		
		System.out.println("Total Weekly Rentals: " + weekCount);
		System.out.println("Total Weekly Gross Cost: " + totalWeeklyCost);
		System.out.println("Final Total: " + finalWeeklyTotal);
	}

	// you can change this to be 'main' and test your Company class with some of the code below.
	public static void main(String[] args)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");
		Company c = new Company();
		c.loadRentals("H:/Courses/CPT237/Spring-2018-changes/RentalRecords.txt");
		c.showAllRentals();
		Rental r = c.findRentalById("NONE-0000");
		System.out.printf("%15s: %10s\n", "Item ID:", sdf.format(r.getDate()));
		System.out.printf("%15s: %10d\n", "Rental Period:", r.getNumPeriods());
		System.out.printf("%15s: %10.2f\n", "Gross Rental:", r.getGrossCost());
		System.out.printf("%15s: %10.2f\n", "Discount:", r.getDiscount());
	}
}
