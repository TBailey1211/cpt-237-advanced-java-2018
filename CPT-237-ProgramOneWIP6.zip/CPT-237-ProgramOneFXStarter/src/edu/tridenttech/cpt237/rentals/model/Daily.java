package edu.tridenttech.cpt237.rentals.model;

import java.util.Date;

//Subclass for Rental: Daily
public class Daily extends Rental 
{
	
	double bikeCost = 5;
	double umbrellaCost = 15;
	
	public Daily(String item, Date date, int numPeriods) 
	{
		super(item, date, numPeriods);
		
		if (item.equals("Bike"))
		{
			rentalPeriod = "Daily";
			grossCost = bikeCost * numPeriods;
			if (numPeriods % 5 == 0 || numPeriods > 5)
			{
				discount = bikeCost;
				finalCost = grossCost - discount;
			}
		}
		
		if (item.equals("Umbrella"))
		{
			rentalPeriod = "Daily";
			grossCost = umbrellaCost * numPeriods;
			if (numPeriods % 5 == 0 || numPeriods > 5)
			{
				discount = umbrellaCost;
				finalCost = grossCost - discount;
			}
		}
		
	}

}
