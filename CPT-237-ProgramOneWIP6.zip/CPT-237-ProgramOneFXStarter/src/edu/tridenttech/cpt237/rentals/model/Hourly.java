package edu.tridenttech.cpt237.rentals.model;

import java.util.Date;

//Subclass for Rental: Hourly
public class Hourly extends Rental 
{

	double seaDooCost = 50;
	double getawayCost = 35;
	

	public Hourly(String item, Date date, int numPeriods) 
	{
		super(item, date, numPeriods);
		
		if (item.equals("SeaDoo"))
		{
			rentalPeriod = "Hourly";
			grossCost = seaDooCost * numPeriods;
			if (numPeriods >= 3)
			{
				discount = numPeriods * 5;
				finalCost = grossCost - discount;
			}
		}
		
		if (item.equals("Getaway"))
		{
			rentalPeriod = "Hourly";
			grossCost = getawayCost * numPeriods;
			if (numPeriods >= 3)
			{
				discount = numPeriods * 5;
				finalCost = grossCost - discount;
			}
		}
		
	}

}
