package edu.tridenttech.cpt237.rentals.model;

import java.util.Date;

public class LoadRecord extends Rental 
{
	
	private Date date;
	private String rentalId;
	private String itemName;
	private int numPeriods;
	
	public LoadRecord(String item, Date date, int numPeriods, String fileName) 
	{
		super(item, date, numPeriods);
		
		String[] fields = fileName.split(",");
		
		//Date? I'm having trouble finding any examples in the reading 
		//for how to handle this data type 
		//date = fields[0]; < cannot convert String to Date
		rentalId = fields[1];
		itemName = fields[2];
		numPeriods = Integer.parseInt(fields[3]);
		
	}

}
